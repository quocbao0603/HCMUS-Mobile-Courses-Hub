package com.example.courseshub.Course.CourseInfo;

import com.example.courseshub.Course.Course;

public class CourseInfo {
    private Course course;
    private String des;
    private String syllabus;
}
